#ifndef COORDINATE_SYSTEM_DEMO_H
#define COORDINATE_SYSTEM_DEMO_H

class	CommonExampleInterface*    CoordinateSystemCreateFunc(struct CommonExampleOptions& options);


#endif //COORDINATE_SYSTEM_DEMO_H

