#ifndef IMPORT_OBJ_EXAMPLE_H
#define IMPORT_OBJ_EXAMPLE_H

class CommonExampleInterface*    ImportObjCreateFunc(struct CommonExampleOptions& options);


#endif //IMPORT_OBJ_EXAMPLE_H
